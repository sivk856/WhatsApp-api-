import { useEffect, useState } from "react";
import axios from "axios";

export default function Dashboard() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      const res = await axios.get("http://localhost:5000/api/users", {
        headers: { Authorization: localStorage.getItem("token") }
      });
      setUsers(res.data);
    };
    fetchUsers();
  }, []);

  return (
    <div>
      <h1>Dashboard</h1>
      {users.map(user => (
        <div key={user._id}>{user.email}</div>
      ))}
    </div>
  );
}
